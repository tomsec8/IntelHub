import { brw, flashButton } from './modules/utils.js'; 
import { initializeFavorites } from './modules/favorites.js';
import { initializeOsintTools, restoreOsintToolsView } from './modules/osintTools.js';
import { initializeDorks, restoreDorksView } from './modules/dorks.js';
import { initializeTelegramAnalyzer, restoreTelegramView } from './modules/telegramAnalyzer.js';
import { initializeSiteAnalyzer, restoreSiteAnalyzerView } from './modules/siteAnalyzer.js';
import { initializeMetadataAnalyzer, restoreMetadataView } from './modules/metadataAnalyzer.js';
import { initializeReverseImageSearch } from './modules/reverseImageSearch.js';
import { initializeSocialIdExtractor } from './modules/socialIdExtractor.js';
import { initializeTextProfiler, restoreTextProfilerView } from './modules/textProfiler.js';
import { initializeHelpSection } from './modules/help.js';
import { initializeInvestigationGraph } from './modules/investigationGraph.js';

const GITHUB_TOOLS_URL = "https://raw.githubusercontent.com/tomsec8/IntelHub/main/tools.json";
let toolsData = {};
let allToolsFlat = [];

document.addEventListener('DOMContentLoaded', () => {
  
  const manifest = chrome.runtime.getManifest();
  const versionEl = document.getElementById('versionNumber');
  if (versionEl) {
      versionEl.textContent = `v${manifest.version}`;
  }

  const themeLink = document.getElementById('theme-stylesheet');
  const themeToggleBtn = document.getElementById('themeToggle');
  const NEW_THEME = 'styles/styles.css';
  const OLD_THEME = 'styles/styles_old.css';

  chrome.storage.local.get(['selectedTheme'], (result) => {
    if (result.selectedTheme) {
      themeLink.setAttribute('href', result.selectedTheme);
    }
  });

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const currentTheme = themeLink.getAttribute('href');
      const nextTheme = currentTheme === NEW_THEME ? OLD_THEME : NEW_THEME;

      themeLink.setAttribute('href', nextTheme);
      chrome.storage.local.set({ selectedTheme: nextTheme });
      
      flashButton(themeToggleBtn, '🎨'); 
    });
  }
  // ===============================================

  chrome.storage.session.get(['lastState'], (result) => {
    if (result.lastState) {
      restoreLastView(result.lastState);
    } else {
      manageToolUpdates();
    }
  });

  document.getElementById('refreshButton').addEventListener('click', forceToolUpdate);

  const mainContainer = document.querySelector('.container');
  let scrollTimer;
  
  if (mainContainer) {
      mainContainer.addEventListener('scroll', () => {
          clearTimeout(scrollTimer);
          scrollTimer = setTimeout(() => {
              const storage = chrome.storage.session || chrome.storage.local;
              const currentScroll = mainContainer.scrollTop;
              
              storage.get(['lastState'], (result) => {
                  const state = result.lastState || { view: 'home' };
                  state.scrollTop = currentScroll;
                  storage.set({ lastState: state });
              });
          }, 150);
      });
  }
});

function restoreLastView(state) {
  chrome.storage.local.get(['toolsData'], (result) => {
    if (result.toolsData) {
      toolsData = result.toolsData;
      flattenTools(toolsData);
      
      renderUI({ tools: toolsData, isRestoring: true });

      const container = document.getElementById("categoryButtons");
      
      switch (state.view) {
        case 'search':
          document.getElementById('searchBox').value = state.query;
          if (state.query) {
            performSearch(state.query);
          }
          break;

        case 'metadataAnalyzer':
            restoreMetadataView(container, state);
            break;
        
        case 'dorks':
            restoreDorksView(container, state);
            break;

        case 'osintTools':
            restoreOsintToolsView(container, state, toolsData, forceToolUpdate);
            break;

        case 'siteAnalyzer':
            restoreSiteAnalyzerView(container, state);
            break;
        
        case 'telegram':
            restoreTelegramView(container);
            break;

        case 'textProfiler':
            restoreTextProfilerView(container, state);
            break;
        
        default:
          break;
      }

      if (state.scrollTop && state.scrollTop > 0) {
          setTimeout(() => {
              const mainContainer = document.querySelector('.container');
              if (mainContainer) {
                  mainContainer.scrollTo({
                      top: state.scrollTop,
                      behavior: "instant"
                  });
              }
          }, 100);
      }

    } else {
      manageToolUpdates();
    }
  });
}

function manageToolUpdates() {
  renderUI({ isLoading: true });

  chrome.storage.local.get(['toolsData', 'lastUpdated'], (result) => {
    const { toolsData: cachedTools, lastUpdated } = result;
    const now = new Date().getTime();
    const oneDay = 24 * 60 * 60 * 1000;

    if (cachedTools) {
      renderUI({ tools: cachedTools });
    }

    if (!lastUpdated || (now - lastUpdated > oneDay)) {
      fetch(GITHUB_TOOLS_URL)
        .then(response => response.ok ? response.json() : Promise.reject('Network error'))
        .then(newTools => {
          chrome.storage.local.set({
            toolsData: newTools,
            lastUpdated: new Date().getTime()
          });
          if (!cachedTools) {
            renderUI({ tools: newTools });
          }
        }).catch(error => {
          console.error("Background fetch failed:", error);
          if (!cachedTools) {
            renderUI({ error: "Failed to load OSINT tools." });
          }
        });
    }
  });
}

function forceToolUpdate() {
    chrome.storage.session.remove('lastState');
    const refreshButton = document.getElementById('refreshButton');
    if (refreshButton) {
        refreshButton.textContent = '⏳';
        refreshButton.disabled = true;
    }

    fetch(GITHUB_TOOLS_URL)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(newTools => {
            chrome.storage.local.set({
                toolsData: newTools,
                lastUpdated: new Date().getTime()
            }, () => {
                renderUI({ tools: newTools });
                flashButton('refreshButton', 'Updated!');
            });
        })
        .catch(error => {
            console.error("Failed to force fetch new tools:", error);
            flashButton('refreshButton', 'Failed', true);
            renderUI({ tools: toolsData });
        })
        .finally(() => {
            if (refreshButton) {
                refreshButton.textContent = 'Refresh';
                refreshButton.disabled = false;
            }
        });
}

function renderUI({ tools = null, isLoading = false, error = null, isRestoring = false }) {
  if (!isRestoring) {
    chrome.storage.session.set({ lastState: { view: 'home' } });
  }
  
  toolsData = tools;
  if (tools) {
    flattenTools(tools);
  }

  const container = document.getElementById("categoryButtons");
  container.innerHTML = "";

  const reRenderWithCurrentTools = () => renderUI({ tools: toolsData });

  initializeFavorites(container, reRenderWithCurrentTools);
  
  if (tools) {
    initializeOsintTools(container, tools, forceToolUpdate);
  } else if (isLoading) {
    const loadingP = document.createElement('p');
    loadingP.textContent = "Loading OSINT tools...";
    container.appendChild(loadingP);
  } else if (error) {
    const errorP = document.createElement('p');
    errorP.style.color = 'red';
    errorP.textContent = error;
    container.appendChild(errorP);
  }

  initializeReverseImageSearch(container);
  initializeMetadataAnalyzer(container);
  initializeDorks(container);
  initializeTelegramAnalyzer(container);
  initializeSiteAnalyzer(container); 
  initializeSocialIdExtractor(container);
  initializeTextProfiler(container);
  initializeInvestigationGraph(container);
  initializeHelpSection(container);

  const loader = document.getElementById('initial-loader');
  if (loader) {
    loader.style.opacity = '0';
    setTimeout(() => {
      loader.style.display = 'none';
    }, 300);
  }
}

function flattenTools(data) {
  allToolsFlat = [];
  for (const category in data) {
    data[category].forEach((tool) => {
      allToolsFlat.push({ ...tool, category });
    });
  }
}

function performSearch(query) {
  const container = document.getElementById("categoryButtons");
  container.innerHTML = "";

  if (!allToolsFlat || allToolsFlat.length === 0) {
      const noResult = document.createElement('p');
      noResult.textContent = 'OSINT tools are not available for search.';
      noResult.style.textAlign = 'center';
      container.appendChild(noResult);
      return;
  }

  const results = allToolsFlat.filter(
    (tool) =>
      tool.name.toLowerCase().includes(query) ||
      tool.description.toLowerCase().includes(query)
  );

  const title = document.createElement("h2");
  title.textContent = `Search Results (${results.length})`;
  title.style.textAlign = "center";
  title.style.fontSize = "16px";
  container.appendChild(title);

  if (results.length === 0) {
      const noResult = document.createElement('p');
      noResult.textContent = 'No tools found.';
      noResult.style.textAlign = 'center';
      container.appendChild(noResult);
  } else {
      results.forEach((tool) => {
        const toolCard = document.createElement("div");
        toolCard.className = "tool-card";
        toolCard.textContent = tool.name;
        toolCard.title = tool.description;
        toolCard.addEventListener("click", () => window.open(tool.url, "_blank"));
        container.appendChild(toolCard);
      });
  }
}

document.getElementById("searchBox").addEventListener("input", function (e) {
  const query = e.target.value.toLowerCase().trim();
  chrome.storage.session.set({ lastState: { view: 'search', query: query } });
  
  if (!query) {
    renderUI({ tools: toolsData });
    return;
  }
  
  performSearch(query);
});