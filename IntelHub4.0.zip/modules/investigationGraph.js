import { brw } from './utils.js';

export function initializeInvestigationGraph(container) {
    const graphBtn = document.createElement("button");
    graphBtn.className = "category-button";
    graphBtn.textContent = "Investigation Graph";

    graphBtn.addEventListener("click", () => {
        brw.tabs.create({ url: 'modules/investigationGraph/index.html' });
    });

    container.appendChild(graphBtn);
}