import { brw, isFirefox, flashButton } from './utils.js';

let lastMetadata = null;

function renderMetadataTable(file, data) {
    const output = createResultsContainer(`Metadata for: ${file.name}`);
    const table = document.createElement("table");
    for (const key in data) {
        const result = data[key];
        const value = result.value;

        const row = table.insertRow();
        const keyCell = row.insertCell();
        keyCell.textContent = key;
        keyCell.style.fontWeight = 'bold';
        const valueCell = row.insertCell();

        if (value) {
            const displayValue = value instanceof Date ? value.toLocaleString() : value.toString();
            valueCell.textContent = displayValue;
        } else if (result.error) {
            valueCell.textContent = `[Could not read field]`;
            valueCell.title = result.error;
            valueCell.style.color = "#ff7675";
            valueCell.style.fontStyle = 'italic';
        } else {
             valueCell.textContent = ``;
        }
    }
    output.appendChild(table);
}

function openUploadPage(type) {
    brw.tabs.create({
        url: `firefox/metadata-upload.html?type=${type}`
    });
    window.close(); 
}

function handleLocalImageUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (e) {
        const metadata = { file: { name: file.name } };
        try {
            const tags = ExifReader.load(e.target.result);
            if (Object.keys(tags).length === 0) throw new Error("No EXIF data found.");
            
            for (const tag in tags) {
                if (tags[tag] && tags[tag].description) {
                    metadata[tag] = { value: tags[tag].description };
                }
            }
        } catch (err) { 
            console.error("EXIF Error:", err);
            const basicInfo = {
                "File Name": { value: file.name },
                "File Size": { value: `${(file.size / 1024).toFixed(2)} KB` },
                "MIME Type": { value: file.type },
                "Last Modified": { value: new Date(file.lastModified).toLocaleString() }
            };
            lastMetadata = { file: { name: file.name }, data: basicInfo };
            renderMetadataTable(lastMetadata.file, lastMetadata.data);
            return;
        }
        lastMetadata = { file: { name: file.name }, data: metadata };
        renderMetadataTable(lastMetadata.file, lastMetadata.data);
    };
    reader.readAsArrayBuffer(file);
}

function handlePdfMetadata(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async function (e) {
        try {
            const pdfDoc = await PDFLib.PDFDocument.load(e.target.result, { ignoreEncryption: true });
            
            const getField = (getter) => {
                try { return { value: getter(), error: null }; } 
                catch (e) { return { value: null, error: e.message }; }
            };
            
            const fields = {
                "Title": getField(() => pdfDoc.getTitle()), "Author": getField(() => pdfDoc.getAuthor()),
                "Subject": getField(() => pdfDoc.getSubject()), "Keywords": getField(() => pdfDoc.getKeywords()),
                "Creator": getField(() => pdfDoc.getCreator()), "Producer": getField(() => pdfDoc.getProducer()),
                "Creation Date": getField(() => pdfDoc.getCreationDate()), "Modification Date": getField(() => pdfDoc.getModificationDate())
            };
            lastMetadata = { file: { name: file.name }, data: fields };
            renderMetadataTable(lastMetadata.file, lastMetadata.data);
        } catch (err) {
            console.error("PDF Error:", err);
            console.warn("Could not read PDF metadata");
        }
    };
    reader.readAsArrayBuffer(file);
}

function handleOfficeMetadata(event) {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async function (e) {
        try {
            const zip = await JSZip.loadAsync(e.target.result);
            const metadataFiles = ["docProps/core.xml", "docProps/app.xml"];
            const metadata = {};
            for (const path of metadataFiles) {
                if (zip.files[path]) {
                    const content = await zip.files[path].async("string");
                    const parser = new DOMParser();
                    const xmlDoc = parser.parseFromString(content, "text/xml");
                    const children = xmlDoc.documentElement.childNodes;
                    for (const node of children) {
                        if (node.nodeType === 1) metadata[node.nodeName] = { value: node.textContent };
                    }
                }
            }
            lastMetadata = { file: { name: file.name }, data: metadata };
            renderMetadataTable(lastMetadata.file, lastMetadata.data);
        } catch (err) {
            console.error("Office Error:", err);
            alert("Could not read metadata from this Office file.");
        }
    };
    reader.readAsArrayBuffer(file);
}

function createResultsContainer(titleText) {
    const mainContainer = document.getElementById('categoryButtons');
    const existingOutput = document.getElementById('metadata-output');
    if (existingOutput) existingOutput.remove();

    const output = document.createElement("div");
    output.id = 'metadata-output';
    output.style.padding = "10px"; output.style.marginTop = "10px";
    output.style.background = "#2c1e3f"; output.style.color = "#ffcc99";
    output.style.borderRadius = "12px"; output.style.maxHeight = "250px";
    output.style.overflowY = "auto";
    
    const title = document.createElement("h3");
    title.textContent = titleText;
    title.style.margin = "0 0 10px 0"; title.style.fontSize = "14px";
    output.appendChild(title);

    mainContainer.appendChild(output);
    return output;
}

export function restoreMetadataView(container, state) {
    if (state.mainOpen) {
        const metaBtn = Array.from(container.querySelectorAll('.category-button')).find(btn => btn.textContent === "Metadata Analyzer");
        if (metaBtn) {
            const metaWrapper = metaBtn.nextElementSibling;
            if (metaWrapper) metaWrapper.classList.add("open");
        }
    }
    if (state.metadata) {
        lastMetadata = state.metadata;
        renderMetadataTable(lastMetadata.file, lastMetadata.data);
    }
}

export function initializeMetadataAnalyzer(container) {
    const metaBtn = document.createElement("button");
    metaBtn.className = "category-button";
    metaBtn.textContent = "Metadata Analyzer";
    const metaWrapper = document.createElement("div");
    metaWrapper.className = "tool-list";

    function saveMetadataState() {
        const isMainOpen = metaWrapper.classList.contains("open");
        if (!isMainOpen) {
            chrome.storage.session.set({ lastState: { view: 'home' } });
            return;
        }
        chrome.storage.session.set({
            lastState: {
                view: 'metadataAnalyzer',
                mainOpen: isMainOpen,
                metadata: lastMetadata
            }
        });
    }

    metaBtn.addEventListener("click", () => {
        metaWrapper.classList.toggle("open");
        if (!metaWrapper.classList.contains("open")) {
            const existing = document.getElementById("metadata-output");
            if (existing) existing.remove();
            lastMetadata = null;
        }
        saveMetadataState();
    });
    
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.style.display = 'none';
    document.body.appendChild(fileInput);

    const createBtn = (text, accept, handler) => {
        const btn = document.createElement("button");
        btn.className = "sub-category-button";
        btn.textContent = text;
        btn.addEventListener("click", () => {
            if (isFirefox()) {
                openUploadPage(accept.replace(/[^a-zA-Z]/g, ''));
            } else { 
                fileInput.accept = accept;
                fileInput.onchange = (e) => { handler(e); setTimeout(saveMetadataState, 100); };
                fileInput.click();
            }
        });
        return btn;
    };

    metaWrapper.appendChild(createBtn("Upload image file", "image/*", handleLocalImageUpload));
    metaWrapper.appendChild(createBtn("Upload PDF file", ".pdf", handlePdfMetadata));
    metaWrapper.appendChild(createBtn("Upload Office file", ".docx,.xlsx,.pptx", handleOfficeMetadata));
    container.appendChild(metaBtn);
    container.appendChild(metaWrapper);
}